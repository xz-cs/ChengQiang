<?php return array (
  'debug' => false,
  'database' => 
  array (
    'driver' => 'mysql',
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'cssaug_forumdb',
    'username' => 'forumdbuser',
    'password' => 'pU0UQmJf6yMqCXAW',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => 'cssaug',
    'strict' => false,
    'engine' => 'InnoDB',
    'prefix_indexes' => true,
  ),
  'url' => 'http://localhost/forum/public',
  'paths' => 
  array (
    'api' => 'api',
    'admin' => 'admin',
  ),
);