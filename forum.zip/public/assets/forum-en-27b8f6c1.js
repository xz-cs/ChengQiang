flarum.core.app.translator.addTranslations({"therealsujitk.forum.show_password_label":"Show Password","fof-filter.forum.flagger_name":"Auto Moderator","fof-filter.forum.flaged_text":"Contained blocked strings"});

//# sourceMappingURL=http://localhost/forum/public/assets/forum-en-27b8f6c1.js.map