<img src="{@url}" title="{@base_name}" />
