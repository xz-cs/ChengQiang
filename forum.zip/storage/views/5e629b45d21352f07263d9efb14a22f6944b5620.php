<div class="ButtonGroup">
    <div class="Button hasIcon Button--icon Button--primary flagrow-download-button" data-uuid="{@uuid}"><i class="fa fa-download"></i></div>
    <div class="Button">
        <xsl:value-of select="@base_name"/>
    </div>
    <div class="Button">
        <xsl:value-of select="@size"/>
    </div>
</div>
