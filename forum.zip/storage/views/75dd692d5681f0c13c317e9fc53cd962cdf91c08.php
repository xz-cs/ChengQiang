<div class="ButtonGroup">
    <div class="Button hasIcon Button--icon Button--primary flagrow-download-button" data-uuid="{@uuid}"><i class="fa fa-download"></i></div>
    <div class="Button">
        {SIMPLETEXT1}
    </div>
    <div class="Button">
        <xsl:value-of select="@size"/>
    </div>
</div>
